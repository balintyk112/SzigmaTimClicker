@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo ERROR: .NET SDK is not installed.
  echo Install the .NET SDK from https://dotnet.microsoft.com/download
  pause
  exit /b 1
)
echo Building SzigmaTimClicker portable Windows EXE...
dotnet publish "src\SzigmaTimClicker.csproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true -p:DebugType=None -p:DebugSymbols=false -o "publish"
if errorlevel 1 (
  echo Build failed. Read the error messages above.
  pause
  exit /b 1
)
copy /y "publish\SzigmaTimClicker.exe" "SzigmaTimClicker.exe" >nul
if errorlevel 1 (
  echo Failed to copy the EXE.
  pause
  exit /b 1
)
echo.
echo SUCCESS: %CD%\SzigmaTimClicker.exe
pause
