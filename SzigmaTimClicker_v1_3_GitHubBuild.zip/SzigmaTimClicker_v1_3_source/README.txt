SzigmaTimClicker v1.3 — Windows 10/11 x64

CHANGELOG
- Stopwatch deadline-based click scheduler with a short bounded final spin.
- Detection scans on a worker to avoid blocking the UI thread and its global input hooks.
- Click eligibility rechecked after scheduler waits.
- Diagnostics: Sent (successful UP+DOWN pairs), Errors (SendInput failures),
  Late (gaps > 150% of previous target interval), Last gap and Max gap.
- Fixed 15 ms Mouse UP time preserved. FyreMC detection, UI and hotkey preserved.

BUILD
Install .NET 8 SDK on Windows, extract, and run BUILD-WINDOWS.cmd.
Do not run as administrator unless your own environment specifically requires it.
You will find SzigmaTimClicker.exe in the root after a successful build.

TEST
Test at 5 CPS Constant, with FyreMC in windowed mode, and watch both Sent
and Late. A zero Errors count means Windows accepted SendInput calls; it does
NOT guarantee the game or server processed them. 'Late' is an observation,
not proof of the source of an in-game skipped hit.

NOTE
Windows compilation and in-game operation have not been verified here.
Avoid anti-cheat evasion and follow the server's rules.

BUILD WITHOUT INSTALLING .NET ON YOUR PC
----------------------------------------
This source package includes a GitHub Actions workflow at:
.github/workflows/build-windows.yml

To build without installing the .NET SDK on your own computer:
1. Create a GitHub repository and upload the contents of this ZIP.
2. Open the repository's Actions tab.
3. Select "Build portable Windows EXE" and click "Run workflow"
   (or push to the main/master branch).
4. When the run finishes, open it and download the
   "SzigmaTimClicker-win-x64" artifact.

The artifact contains a self-contained Windows x64 EXE. The .NET runtime
is bundled, so the target PC does not need the .NET SDK or runtime installed.
The SDK is still used by GitHub's Windows build machine to compile the EXE.

This package contains source code and a build workflow, NOT a precompiled EXE.
The resulting program has not been independently security-audited.
