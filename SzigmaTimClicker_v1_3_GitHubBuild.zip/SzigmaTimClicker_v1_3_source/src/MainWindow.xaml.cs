using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace SzigmaTimClicker;

public partial class MainWindow : Window
{
    private readonly object _sync = new();
    private readonly DispatcherTimer _detectorTimer;
    private readonly CancellationTokenSource _stopToken = new();
    private readonly Native.HookProc _keyboardCallback;
    private readonly Native.HookProc _mouseCallback;
    private IntPtr _keyboardHook;
    private IntPtr _mouseHook;
    private readonly HashSet<uint> _pressedKeys = new();

    // Shared across UI, hook callbacks, and the clicking task; always access under _sync.
    private bool _activation;
    private bool _physicalDown;
    private bool _releaseRequired;
    private bool _randomized;
    private bool _awaitingHotkey;
    private int _hotkey = 0x75; // VK_F6
    private int _cps = 12;
    private int _variation = 2;
    private Detection _detected = Detection.Empty;
    private bool _disposed;
    // Diagnostics count successful complete release/press pairs and failed SendInput calls.
    private long _sentCycles;
    private long _sendFailures;
    private long _lateCycles;
    private long _maxGapMs;
    private long _lastGapMs;
    private int _scanInProgress;
    private const double LateCycleMultiplier = 1.5;
    private const int MouseUpMilliseconds = 15;
    private readonly Random _random = new(); // used by the worker task only

    public MainWindow()
    {
        InitializeComponent();
        _keyboardCallback = KeyboardHook;
        _mouseCallback = MouseHook;
        UpdateCpsUi();
        UpdateActivationUi();
        UpdateModeUi();
        UpdateDetectionUi();
        UpdateDiagnosticsUi();

        _keyboardHook = Native.SetWindowsHookEx(Native.WH_KEYBOARD_LL, _keyboardCallback, Native.GetModuleHandle(null), 0);
        _mouseHook = Native.SetWindowsHookEx(Native.WH_MOUSE_LL, _mouseCallback, Native.GetModuleHandle(null), 0);
        if (_keyboardHook == IntPtr.Zero || _mouseHook == IntPtr.Zero)
        {
            MessageBox.Show("Could not install global input hooks. Try running the app normally on Windows.\n\nWindows error: " + Marshal.GetLastWin32Error(),
                "SzigmaTimClicker", MessageBoxButton.OK, MessageBoxImage.Error);
            Close();
            return;
        }

        _detectorTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(500) };
        _detectorTimer.Tick += (_, _) => _ = ScanMinecraftAsync();
        _ = ScanMinecraftAsync();
        _detectorTimer.Start();
        _ = Task.Run(() => ClickLoop(_stopToken.Token));
    }

    private IntPtr KeyboardHook(int code, IntPtr wp, IntPtr lp)
    {
        if (code < 0) return Native.CallNextHookEx(_keyboardHook, code, wp, lp);
        var data = Marshal.PtrToStructure<Native.KBDLLHOOKSTRUCT>(lp);
        if ((data.flags & Native.LLKHF_INJECTED) != 0) return Native.CallNextHookEx(_keyboardHook, code, wp, lp);
        int msg = wp.ToInt32();
        bool down = msg is Native.WM_KEYDOWN or Native.WM_SYSKEYDOWN;
        bool up = msg is Native.WM_KEYUP or Native.WM_SYSKEYUP;
        if (!down && !up) return Native.CallNextHookEx(_keyboardHook, code, wp, lp);
        bool changed = false;
        bool captured = false;
        lock (_sync)
        {
            if (up) _pressedKeys.Remove(data.vkCode);
            else if (_pressedKeys.Add(data.vkCode))
            {
                if (_awaitingHotkey)
                {
                    _hotkey = checked((int)data.vkCode);
                    _awaitingHotkey = false;
                    captured = true;
                }
                else if (data.vkCode == _hotkey)
                {
                    _activation = !_activation;
                    if (!_activation || _physicalDown) _releaseRequired = _physicalDown;
                    changed = true;
                }
            }
        }
        if (changed || captured)
            Dispatcher.BeginInvoke(() => { if (changed) UpdateActivationUi(); if (captured) UpdateHotkeyUi(); });
        return Native.CallNextHookEx(_keyboardHook, code, wp, lp); // Never suppress the game's key.
    }

    private IntPtr MouseHook(int code, IntPtr wp, IntPtr lp)
    {
        if (code >= 0)
        {
            int msg = wp.ToInt32();
            if (msg == Native.WM_LBUTTONDOWN || msg == Native.WM_LBUTTONUP)
            {
                var data = Marshal.PtrToStructure<Native.MSLLHOOKSTRUCT>(lp);
                if ((data.flags & Native.LLMHF_INJECTED) == 0) // Ignore all synthetic clicks.
                {
                    lock (_sync)
                    {
                        if (msg == Native.WM_LBUTTONDOWN)
                        {
                            if (!_physicalDown)
                            {
                                _physicalDown = true;
                                // Do not disarm if the app is ON and window is eligible.
                                if (!CanClickInCurrentWindow()) _releaseRequired = true;
                            }
                        }
                        else
                        {
                            _physicalDown = false;
                            _releaseRequired = false;
                        }
                    }
                }
            }
        }
        return Native.CallNextHookEx(_mouseHook, code, wp, lp);
    }

    private bool CanClickInCurrentWindow()
    {
        if (_detected.Status == DetectionStatus.Uncertain) return false;
        if (_detected.Status == DetectionStatus.NotFound) return true;
        return _detected.GameWindows.Contains(Native.GetForegroundWindow());
    }

    // Use monotonic time for scheduling. Each cycle begins at a deadline rather than
    // sleeping a full period after the 15 ms UP interval, which otherwise loses CPS.
    private void WaitForDeadline(long due, CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            double remainingMs = (due - Stopwatch.GetTimestamp()) * 1000.0 / Stopwatch.Frequency;
            if (remainingMs <= 0) return;
            if (remainingMs > 3)
            {
                // Leave a small margin for normal Windows scheduler jitter.
                int waitMs = Math.Max(1, (int)Math.Floor(remainingMs - 1.5));
                if (token.WaitHandle.WaitOne(waitMs)) return;
            }
            else
            {
                // Fine-grained finish; bounded to under ~3 ms per cycle.
                Thread.SpinWait(64);
            }
        }
    }

    private void ClickLoop(CancellationToken token)
    {
        long nextAt = 0;
        long previousCycleStart = 0;
        long expectedPreviousPeriod = 0;
        bool lastEligible = false;
        IntPtr lastWindow = IntPtr.Zero;
        while (!token.IsCancellationRequested)
        {
            bool eligible;
            int cps;
            int variation;
            bool random;
            var window = Native.GetForegroundWindow();
            lock (_sync)
            {
                if (_physicalDown && _detected.Status == DetectionStatus.Found && !_detected.GameWindows.Contains(window))
                    _releaseRequired = true;
                if (_physicalDown && lastEligible && lastWindow != window)
                    _releaseRequired = true;
                eligible = !_disposed && _activation && _physicalDown && !_releaseRequired && CanClickInCurrentWindow();
                cps = _cps;
                variation = _variation;
                random = _randomized;
            }
            if (!eligible)
            {
                nextAt = 0;
                previousCycleStart = 0;
                lastEligible = false;
                if (token.WaitHandle.WaitOne(5)) break;
                continue;
            }
            if (!lastEligible)
            {
                nextAt = 0;
                previousCycleStart = 0;
                lastEligible = true;
                lastWindow = window;
            }

            // Resume immediately on a newly eligible physical press, otherwise
            // wait until the previous cycle's monotonic deadline.
            if (nextAt != 0) WaitForDeadline(nextAt, token);
            if (token.IsCancellationRequested) break;

            // Recheck state AFTER waiting. A focus change or mouse-up may have
            // occurred during the wait; never click into an ineligible window.
            window = Native.GetForegroundWindow();
            lock (_sync)
            {
                if (_physicalDown && lastWindow != window) _releaseRequired = true;
                eligible = !_disposed && _activation && _physicalDown && !_releaseRequired && CanClickInCurrentWindow();
                cps = _cps;
                variation = _variation;
                random = _randomized;
            }
            if (!eligible)
            {
                nextAt = 0;
                previousCycleStart = 0;
                lastEligible = false;
                continue;
            }

            long cycleStart = Stopwatch.GetTimestamp();
            if (previousCycleStart != 0)
            {
                long gapMs = (long)Math.Round((cycleStart - previousCycleStart) * 1000.0 / Stopwatch.Frequency);
                Interlocked.Exchange(ref _lastGapMs, gapMs);
                if (gapMs > Interlocked.Read(ref _maxGapMs))
                {
                    long prev;
                    do
                    {
                        prev = Interlocked.Read(ref _maxGapMs);
                        if (gapMs <= prev) break;
                    } while (Interlocked.CompareExchange(ref _maxGapMs, gapMs, prev) != prev);
                }
                if (expectedPreviousPeriod > 0 &&
                    cycleStart - previousCycleStart > expectedPreviousPeriod * LateCycleMultiplier)
                    Interlocked.Increment(ref _lateCycles);
            }
            previousCycleStart = cycleStart;
            double speed = random
                ? Math.Clamp(cps + ((_random.NextDouble() * 2 - 1) * variation), 1.0, 20.0)
                : cps;
            long period = (long)(Stopwatch.Frequency / speed);
            expectedPreviousPeriod = period;
            nextAt = cycleStart + period;

            // Physical left button is already held. A short synthetic UP/DOWN
            // pair produces a new press without feeding our own hook back.
            if (!Native.MouseEvent(Native.MOUSEEVENTF_LEFTUP))
            {
                Interlocked.Increment(ref _sendFailures);
                if (token.WaitHandle.WaitOne(MouseUpMilliseconds)) break;
                continue;
            }
            bool cancelled = token.WaitHandle.WaitOne(MouseUpMilliseconds);
            bool physicallyHeld;
            lock (_sync) physicallyHeld = _physicalDown;
            bool sameWindow = Native.GetForegroundWindow() == window;

            // Restore DOWN only if still physically held and the foreground did
            // not change. Never send a new DOWN to another application.
            if (physicallyHeld && sameWindow && !cancelled)
            {
                if (Native.MouseEvent(Native.MOUSEEVENTF_LEFTDOWN))
                    Interlocked.Increment(ref _sentCycles);
                else
                    Interlocked.Increment(ref _sendFailures);
            }
            if (cancelled) break;
        }
    }

    // Window enumeration / process metadata can be slow. Keep it off the UI
    // thread so LL mouse and keyboard hooks continue receiving physical events.
    private async Task ScanMinecraftAsync()
    {
        if (Interlocked.Exchange(ref _scanInProgress, 1) != 0) return;
        Detection latest;
        try
        {
            latest = await Task.Run(() =>
            {
                try { return MinecraftDetector.Scan(); }
                catch { return new Detection(DetectionStatus.Uncertain, "Detection error", new HashSet<IntPtr>()); }
            });
        }
        finally { Interlocked.Exchange(ref _scanInProgress, 0); }
        if (_stopToken.IsCancellationRequested) return;
        bool turnedOff = false;
        lock (_sync)
        {
            if (_disposed) return;
            var prior = _detected.Status;
            _detected = latest;
            if (prior == DetectionStatus.Found && latest.Status == DetectionStatus.NotFound)
            {
                _activation = false;
                turnedOff = true;
            }
            if (_physicalDown && prior != latest.Status) _releaseRequired = true;
        }
        if (turnedOff) UpdateActivationUi();
        UpdateDetectionUi();
        UpdateDiagnosticsUi();
    }

    private void UpdateDiagnosticsUi()
    {
        if (DiagnosticsText is null) return;
        DiagnosticsText.Text = $"Sent: {Interlocked.Read(ref _sentCycles)}  •  Errors: {Interlocked.Read(ref _sendFailures)}  •  UP: 15 ms";
        TimingText.Text = $"Late: {Interlocked.Read(ref _lateCycles)}  •  Last gap: {Interlocked.Read(ref _lastGapMs)} ms  •  Max: {Interlocked.Read(ref _maxGapMs)} ms";
    }

    private void UpdateCpsUi()
    {
        if (CpsText is null || VariationText is null || RangeText is null) return;
        int cps, variation;
        lock (_sync) { cps = _cps; variation = _variation; }
        CpsText.Text = cps.ToString();
        VariationText.Text = $"±{variation} CPS";
        RangeText.Text = $"Range: {Math.Max(1, cps - variation)}–{Math.Min(20, cps + variation)} CPS";
    }

    private void UpdateModeUi()
    {
        if (VariationPanel is null) return;
        bool randomized;
        lock (_sync) randomized = _randomized;
        VariationPanel.Visibility = randomized ? Visibility.Visible : Visibility.Collapsed;
        ConstantButton.Background = (Brush)new BrushConverter().ConvertFromString(randomized ? "#111B27" : "#31465D")!;
        RandomButton.Background = (Brush)new BrushConverter().ConvertFromString(randomized ? "#31465D" : "#111B27")!;
    }

    private void UpdateActivationUi()
    {
        if (ActivationButton is null) return;
        bool enabled;
        lock (_sync) enabled = _activation;
        ActivationButton.Content = enabled ? "ON" : "OFF";
        ActivationButton.Background = (Brush)new BrushConverter().ConvertFromString(enabled ? "#2B6B87" : "#354253")!;
        ActivationHint.Text = enabled ? "Ready · Hold left click" : "Hold left click to operate";
    }

    private void UpdateHotkeyUi()
    {
        if (HotkeyButton is null) return;
        int vk;
        bool awaiting;
        lock (_sync) { vk = _hotkey; awaiting = _awaitingHotkey; }
        HotkeyButton.Content = awaiting ? "Press any key…" : KeyInterop.KeyFromVirtualKey(vk).ToString();
    }

    private void UpdateDetectionUi()
    {
        if (DetectionText is null) return;
        Detection info;
        lock (_sync) info = _detected;
        DetectionText.Text = info.Status switch
        {
            DetectionStatus.Found => "FOUND",
            DetectionStatus.Uncertain => "UNCERTAIN",
            _ => "NOT FOUND"
        };
        DetectionBadge.Background = (Brush)new BrushConverter().ConvertFromString(info.Status switch
        {
            DetectionStatus.Found => "#214D48",
            DetectionStatus.Uncertain => "#615028",
            _ => "#344253"
        })!;
        WindowTitleText.Text = info.Title;
        WindowTitleText.ToolTip = info.Title;
        ScopeText.Text = info.Status switch
        {
            DetectionStatus.Found => "Minecraft Only",
            DetectionStatus.Uncertain => "Paused",
            _ => "Global"
        };
    }

    private void CpsSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        lock (_sync) _cps = (int)Math.Round(e.NewValue);
        UpdateCpsUi();
    }
    private void VariationSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        lock (_sync) _variation = (int)Math.Round(e.NewValue);
        UpdateCpsUi();
    }
    private void Constant_Click(object sender, RoutedEventArgs e) { lock (_sync) _randomized = false; UpdateModeUi(); }
    private void Random_Click(object sender, RoutedEventArgs e) { lock (_sync) _randomized = true; UpdateModeUi(); }
    private void Activation_Click(object sender, RoutedEventArgs e)
    {
        lock (_sync)
        {
            _activation = !_activation;
            if (!_activation || _physicalDown) _releaseRequired = _physicalDown;
        }
        UpdateActivationUi();
    }
    private void Hotkey_Click(object sender, RoutedEventArgs e)
    {
        lock (_sync) _awaitingHotkey = true;
        UpdateHotkeyUi();
    }
    private void Header_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton == MouseButton.Left && e.ClickCount == 1)
            try { DragMove(); } catch (InvalidOperationException) { }
    }
    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    protected override void OnClosing(CancelEventArgs e)
    {
        lock (_sync) { _disposed = true; _activation = false; }
        _stopToken.Cancel();
        if (_detectorTimer is not null) _detectorTimer.Stop();
        if (_keyboardHook != IntPtr.Zero) { Native.UnhookWindowsHookEx(_keyboardHook); _keyboardHook = IntPtr.Zero; }
        if (_mouseHook != IntPtr.Zero) { Native.UnhookWindowsHookEx(_mouseHook); _mouseHook = IntPtr.Zero; }
        base.OnClosing(e);
    }
}
