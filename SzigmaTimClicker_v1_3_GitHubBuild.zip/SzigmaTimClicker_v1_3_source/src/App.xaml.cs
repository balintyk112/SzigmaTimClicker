using System.Windows;
namespace SzigmaTimClicker;
public partial class App : Application { }
