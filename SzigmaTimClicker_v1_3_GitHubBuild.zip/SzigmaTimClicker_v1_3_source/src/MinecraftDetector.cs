using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace SzigmaTimClicker;

internal enum DetectionStatus { Found, NotFound, Uncertain }

internal sealed record Detection(DetectionStatus Status, string Title, IReadOnlySet<IntPtr> GameWindows)
{
    internal static Detection Empty { get; } = new(DetectionStatus.NotFound, "No Minecraft detected", new HashSet<IntPtr>());
}

internal static class MinecraftDetector
{
    private static readonly string[] GameProcesses = { "java", "javaw", "minecraft", "lunarclient", "lunar client", "badlionclient", "badlion client", "feather", "featherclient", "fyremc" };
    private static readonly string[] LauncherMarkers = { "launcher", "installer", "updater", "login", "sign in", "minecraft launcher" };

    internal static Detection Scan()
    {
        var confirmed = new Dictionary<IntPtr, string>();
        string? uncertainTitle = null;
        Native.EnumWindows((handle, _) =>
        {
            if (!Native.IsWindowVisible(handle)) return true;
            var title = Native.WindowText(handle).Trim();
            if (title.Length == 0) return true;
            Native.GetWindowThreadProcessId(handle, out var pid);
            string process;
            try { using var p = Process.GetProcessById(checked((int)pid)); process = p.ProcessName.ToLowerInvariant(); }
            catch { return true; }
            string lower = title.ToLowerInvariant();
            bool knownProcess = GameProcesses.Any(s => process.Contains(s, StringComparison.OrdinalIgnoreCase));
            bool titleGame = lower.Contains("minecraft") || lower.Contains("lunar client") || lower.Contains("badlion client") || lower.Contains("feather client") || lower.Contains("fyremc");
            if (!knownProcess && !titleGame) return true;
            bool launcher = LauncherMarkers.Any(s => lower.Contains(s)) || process.Contains("launcher") || process.Contains("updater") || process.Contains("installer");
            if (launcher) return true; // A launcher does not count as a game.
            string cls = Native.WindowClass(handle).ToLowerInvariant();
            bool gameClass = cls.Contains("glfw") || cls.Contains("lwjgl") || cls.Contains("sunawtframe");
            bool javaProcess = process is "java" or "javaw";
            bool supportedClient = process.Contains("lunar") || process.Contains("badlion") || process.Contains("feather") || process.Contains("fyremc");

            // Only confidently classify actual Java-game windows, not browser tabs, launchers or dialogs.
            bool game = (javaProcess && (lower.Contains("minecraft") || gameClass)) ||
                        (supportedClient && gameClass && titleGame) ||
                        (process == "minecraft" && gameClass) ||
                        (lower.Contains("fyremc") && gameClass && (javaProcess || supportedClient));
            if (game) confirmed[handle] = title;
            else if (titleGame || (knownProcess && gameClass)) uncertainTitle ??= title;
            return true;
        }, IntPtr.Zero);

        if (confirmed.Count > 0)
        {
            var foreground = Native.GetForegroundWindow();
            var chosen = confirmed.TryGetValue(foreground, out var activeTitle) ? activeTitle : confirmed.Values.First();
            return new Detection(DetectionStatus.Found, chosen, confirmed.Keys.ToHashSet());
        }
        if (uncertainTitle is not null)
            return new Detection(DetectionStatus.Uncertain, uncertainTitle, new HashSet<IntPtr>());
        return Detection.Empty;
    }
}
